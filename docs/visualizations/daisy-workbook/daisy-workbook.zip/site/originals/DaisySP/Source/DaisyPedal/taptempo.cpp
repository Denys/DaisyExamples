#include "taptempo.h"
#include <algorithm>

using namespace daisysp;

void TapTempo::Init(float sample_rate, float default_bpm)
{
    sample_rate_     = sample_rate;
    min_bpm_         = 30.0f;
    max_bpm_         = 300.0f;
    phase_           = 0.0f;
    sample_counter_  = 0;
    last_tap_sample_ = 0;
    have_tap_        = false;
    SetTempoBpm(default_bpm);
}

bool TapTempo::Process()
{
    ++sample_counter_;
    phase_ += phase_inc_;
    if(phase_ >= 1.0f)
    {
        phase_ -= 1.0f;
        return true;
    }
    return false;
}

void TapTempo::TriggerTap()
{
    if(have_tap_)
    {
        const uint32_t delta = sample_counter_ - last_tap_sample_;
        if(delta > 0)
        {
            const float tapped_bpm = (60.0f * sample_rate_) / static_cast<float>(delta);
            if(tapped_bpm >= min_bpm_ && tapped_bpm <= max_bpm_)
            {
                SetTempoBpm(tapped_bpm);
            }
        }
    }
    last_tap_sample_ = sample_counter_;
    have_tap_        = true;
    ResetPhase();
}

void TapTempo::SetTempoBpm(float bpm)
{
    bpm_ = std::max(min_bpm_, std::min(max_bpm_, bpm));
    UpdatePhaseIncrement();
}

void TapTempo::SetMinMaxBpm(float min_bpm, float max_bpm)
{
    min_bpm_ = min_bpm > 1.0f ? min_bpm : 1.0f;
    max_bpm_ = max_bpm > min_bpm_ ? max_bpm : min_bpm_ + 1.0f;
    SetTempoBpm(bpm_);
}

void TapTempo::ResetPhase(float phase)
{
    if(phase < 0.0f)
        phase = 0.0f;
    if(phase > 1.0f)
        phase = 1.0f;
    phase_ = phase;
}

uint32_t TapTempo::GetSamplesPerBeat() const
{
    return static_cast<uint32_t>(sample_rate_ / GetTempoHz());
}

void TapTempo::UpdatePhaseIncrement()
{
    phase_inc_ = GetTempoHz() / sample_rate_;
}
