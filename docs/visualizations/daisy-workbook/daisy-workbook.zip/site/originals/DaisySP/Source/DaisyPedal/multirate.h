/** @file multirate.h
 *  @brief Lightweight low-rate conditioning helper for pedal DSP.
 *  @ingroup pedal_pitch
 */

/*
Copyright (c) 2026

Use of this source code is governed by an MIT-style
license that can be found in the LICENSE file or at
https://opensource.org/licenses/MIT.
*/

#pragma once
#ifndef DSY_PEDAL_MULTIRATE_H
#define DSY_PEDAL_MULTIRATE_H

#include <stddef.h>

#ifdef __cplusplus
#include "Filters/onepole.h"

namespace daisysp
{
/** Lightweight anti-aliased downsampler that returns a held low-rate signal at
 *  the original audio rate.
 *
 *  ## Example
 *  ~~~~
 *  Multirate conditioner;
 *  conditioner.Init(48000.0f, 4);
 *  float held = conditioner.Process(in);
 *  ~~~~
 *
 *  @ingroup pedal_pitch
 */
class Multirate
{
  public:
    Multirate() {}
    ~Multirate() {}

    /** Initialize the multirate helper.
     *  \param sample_rate Input sample rate in Hz.
     *  \param ratio Downsample ratio, where 1 means full rate.
     */
    void Init(float sample_rate, size_t ratio = 2);

    /** Process a sample and return the held low-rate value. */
    float Process(float in);

    /** Set the downsample ratio. */
    void SetRatio(size_t ratio);

    /** Set the anti-alias cutoff in Hz. */
    void SetCutoff(float cutoff_hz);

    /** Returns true if the last Process call captured a fresh low-rate sample. */
    bool FreshSample() const { return fresh_sample_; }

    /** The current low-rate held value. */
    float LowRateValue() const { return held_; }

    /** The current filtered full-rate value before hold/decimation. */
    float FilteredValue() const { return filtered_; }

    /** The current low-rate sample rate. */
    float LowRateSampleRate() const { return sample_rate_ / static_cast<float>(ratio_); }

    /** The current downsample ratio. */
    size_t GetRatio() const { return ratio_; }

  private:
    OnePole anti_alias_;
    float   sample_rate_;
    float   cutoff_hz_;
    float   filtered_;
    float   held_;
    size_t  ratio_;
    size_t  phase_;
    bool    fresh_sample_;
};
} // namespace daisysp
#endif
#endif
