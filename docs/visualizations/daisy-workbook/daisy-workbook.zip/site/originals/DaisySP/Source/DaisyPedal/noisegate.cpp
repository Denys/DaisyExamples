#include "noisegate.h"
#include <algorithm>
#include <cmath>

using namespace daisysp;

void NoiseGate::Init(float sample_rate)
{
    sample_rate_ = sample_rate;
    threshold_   = 0.03f;
    hysteresis_  = 0.01f;
    attack_      = 0.002f;
    release_     = 0.080f;
    range_       = 0.0f;
    envelope_    = 0.0f;
    gain_        = 0.0f;
    is_open_     = false;
    UpdateAttackCoeff();
    UpdateReleaseCoeff();
}

float NoiseGate::Process(float in)
{
    const float detector = fabsf(in);
    const float env_coeff
        = detector > envelope_ ? attack_coeff_ : release_coeff_;
    envelope_ += env_coeff * (detector - envelope_);

    const float close_threshold
        = std::max(0.0f, threshold_ - hysteresis_);

    if(is_open_)
    {
        if(envelope_ < close_threshold)
            is_open_ = false;
    }
    else if(envelope_ >= threshold_)
    {
        is_open_ = true;
    }

    const float target_gain = is_open_ ? 1.0f : range_;
    const float gain_coeff  = is_open_ ? attack_coeff_ : release_coeff_;
    gain_ += gain_coeff * (target_gain - gain_);
    return in * gain_;
}

void NoiseGate::SetThreshold(float threshold)
{
    threshold_ = std::max(0.0f, std::min(1.0f, threshold));
}

void NoiseGate::SetHysteresis(float hysteresis)
{
    hysteresis_ = std::max(0.0f, std::min(1.0f, hysteresis));
}

void NoiseGate::SetAttack(float attack)
{
    attack_ = attack > 0.0f ? attack : 0.0f;
    UpdateAttackCoeff();
}

void NoiseGate::SetRelease(float release)
{
    release_ = release > 0.0f ? release : 0.0f;
    UpdateReleaseCoeff();
}

void NoiseGate::SetRange(float range)
{
    range_ = std::max(0.0f, std::min(1.0f, range));
}

void NoiseGate::UpdateAttackCoeff()
{
    if(attack_ <= 0.0f || sample_rate_ <= 0.0f)
    {
        attack_coeff_ = 1.0f;
        return;
    }
    attack_coeff_ = 1.0f - expf(-1.0f / (attack_ * sample_rate_));
}

void NoiseGate::UpdateReleaseCoeff()
{
    if(release_ <= 0.0f || sample_rate_ <= 0.0f)
    {
        release_coeff_ = 1.0f;
        return;
    }
    release_coeff_ = 1.0f - expf(-1.0f / (release_ * sample_rate_));
}
