#include "bypassfader.h"
#include <cmath>

using namespace daisysp;

void BypassFader::Init(float sample_rate)
{
    sample_rate_ = sample_rate;
    wet_mix_     = 1.0f;
    target_mix_  = 1.0f;
    fade_time_   = 0.01f;
    UpdateStep();
}

float BypassFader::Process(float dry, float wet)
{
    Advance();
    const float dry_mix = 1.0f - wet_mix_;
    return (dry * dry_mix) + (wet * wet_mix_);
}

void BypassFader::Advance()
{
    if(wet_mix_ < target_mix_)
    {
        wet_mix_ += step_;
        if(wet_mix_ > target_mix_)
            wet_mix_ = target_mix_;
    }
    else if(wet_mix_ > target_mix_)
    {
        wet_mix_ -= step_;
        if(wet_mix_ < target_mix_)
            wet_mix_ = target_mix_;
    }
}

void BypassFader::SetBypass(bool bypass)
{
    target_mix_ = bypass ? 0.0f : 1.0f;
}

void BypassFader::SetFadeTime(float fade_time)
{
    fade_time_ = fade_time > 0.0f ? fade_time : 0.0f;
    UpdateStep();
}

bool BypassFader::Transitioning() const
{
    return fabsf(target_mix_ - wet_mix_) > 1.0e-6f;
}

void BypassFader::UpdateStep()
{
    if(fade_time_ <= 0.0f || sample_rate_ <= 0.0f)
    {
        step_ = 1.0f;
        return;
    }

    const float samples = fade_time_ * sample_rate_;
    step_               = samples > 1.0f ? 1.0f / samples : 1.0f;
}
