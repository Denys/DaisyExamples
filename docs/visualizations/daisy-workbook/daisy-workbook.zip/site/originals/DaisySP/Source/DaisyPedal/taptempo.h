/** @file taptempo.h
 *  @brief Tap-tempo helper for pedal footswitch timing.
 *  @ingroup pedal_control
 */

/*
Copyright (c) 2026

Use of this source code is governed by an MIT-style
license that can be found in the LICENSE file or at
https://opensource.org/licenses/MIT.
*/

#pragma once
#ifndef DSY_PEDAL_TAPTEMPO_H
#define DSY_PEDAL_TAPTEMPO_H

#include <stdint.h>

#ifdef __cplusplus
namespace daisysp
{
/** Tap-tempo helper that tracks a beat phase at audio rate.
 *
 *  ## Example
 *  ~~~~
 *  TapTempo tempo;
 *  tempo.Init(48000.0f, 120.0f);
 *  tempo.TriggerTap();
 *  bool downbeat = tempo.Process();
 *  ~~~~
 *
 *  @ingroup pedal_control
 */
class TapTempo
{
  public:
    TapTempo() {}
    ~TapTempo() {}

    /** Initialize the tap tempo helper.
     *  \param sample_rate Audio sample rate in Hz.
     *  \param default_bpm Initial tempo in beats per minute.
     */
    void Init(float sample_rate, float default_bpm = 120.0f);

    /** Advance the phase by one sample.
     *  \return True when a new beat begins.
     */
    bool Process();

    /** Register a new tap. */
    void TriggerTap();

    /** Set the tempo in beats per minute. */
    void SetTempoBpm(float bpm);

    /** Set the valid tap tempo range in BPM. */
    void SetMinMaxBpm(float min_bpm, float max_bpm);

    /** Reset the beat phase.
     *  \param phase New phase in the range 0..1.
     */
    void ResetPhase(float phase = 0.0f);

    /** Current tempo in BPM. */
    float GetTempoBpm() const { return bpm_; }

    /** Current tempo in Hz. */
    float GetTempoHz() const { return bpm_ / 60.0f; }

    /** Current phase in the range 0..1. */
    float GetPhase() const { return phase_; }

    /** Current beat length in milliseconds. */
    float GetMsPerBeat() const { return 60000.0f / bpm_; }

    /** Current beat length in samples. */
    uint32_t GetSamplesPerBeat() const;

  private:
    void UpdatePhaseIncrement();

    float    sample_rate_;
    float    bpm_;
    float    min_bpm_;
    float    max_bpm_;
    float    phase_;
    float    phase_inc_;
    uint32_t sample_counter_;
    uint32_t last_tap_sample_;
    bool     have_tap_;
};
} // namespace daisysp
#endif
#endif
