/** @file bypassfader.h
 *  @brief Smooth bypass-transition helper for pedal signal paths.
 *  @ingroup pedal_control
 */

/*
Copyright (c) 2026

Use of this source code is governed by an MIT-style
license that can be found in the LICENSE file or at
https://opensource.org/licenses/MIT.
*/

#pragma once
#ifndef DSY_PEDAL_BYPASSFADER_H
#define DSY_PEDAL_BYPASSFADER_H

#ifdef __cplusplus
namespace daisysp
{
/** Smooth dry/wet crossfader that is useful for pedal bypass transitions.
 *
 *  ## Example
 *  ~~~~
 *  BypassFader fader;
 *  fader.Init(48000.0f);
 *  fader.SetFadeTime(0.02f);
 *  fader.SetBypass(false);
 *  float mixed = fader.Process(dry, wet);
 *  ~~~~
 *
 *  @ingroup pedal_control
 */
class BypassFader
{
  public:
    BypassFader() {}
    ~BypassFader() {}

    /** Initialize the bypass fader.
     *  \param sample_rate Audio sample rate in Hz.
     */
    void Init(float sample_rate);

    /** Crossfade between dry and wet signals.
     *  \param dry Signal to pass while bypassed.
     *  \param wet Signal to pass while active.
     */
    float Process(float dry, float wet);

    /** Advance the fade state by one sample without mixing audio. */
    void Advance();

    /** Set the bypass state.
     *  \param bypass True favors the dry signal, false favors the wet signal.
     */
    void SetBypass(bool bypass);

    /** Set the fade time in seconds. */
    void SetFadeTime(float fade_time);

    /** Current wet mix position in the range 0..1. */
    float GetFadePosition() const { return wet_mix_; }

    /** Current dry mix position in the range 0..1. */
    float GetDryMix() const { return 1.0f - wet_mix_; }

    /** Returns true while the fader is moving toward its target. */
    bool Transitioning() const;

    /** Returns true when the dry path is the active target. */
    bool Bypassed() const { return target_mix_ <= 0.0f; }

  private:
    void UpdateStep();

    float sample_rate_;
    float fade_time_;
    float wet_mix_;
    float target_mix_;
    float step_;
};
} // namespace daisysp
#endif
#endif
