/** @file noisegate.h
 *  @brief Envelope-following gate for pedal signal chains.
 *  @ingroup pedal_dynamics
 */

/*
Copyright (c) 2026

Use of this source code is governed by an MIT-style
license that can be found in the LICENSE file or at
https://opensource.org/licenses/MIT.
*/

#pragma once
#ifndef DSY_PEDAL_NOISEGATE_H
#define DSY_PEDAL_NOISEGATE_H

#ifdef __cplusplus
namespace daisysp
{
/** Simple envelope-following noise gate with hysteresis.
 *
 *  ## Parameters
 *
 *  - threshold: open threshold in linear amplitude
 *  - hysteresis: close threshold offset below the open threshold
 *  - attack: opening time in seconds
 *  - release: closing time in seconds
 *  - range: closed gain floor in linear amplitude
 *
 *  ## Example
 *  ~~~~
 *  NoiseGate gate;
 *  gate.Init(48000.0f);
 *  gate.SetThreshold(0.03f);
 *  gate.SetRelease(0.08f);
 *  float out = gate.Process(in);
 *  ~~~~
 *
 *  @ingroup pedal_dynamics
 */
class NoiseGate
{
  public:
    NoiseGate() {}
    ~NoiseGate() {}

    /** Initialize the noise gate.
     *  \param sample_rate Audio sample rate in Hz.
     */
    void Init(float sample_rate);

    /** Process a single audio sample through the gate. */
    float Process(float in);

    /** Set the open threshold in linear amplitude (0..1). */
    void SetThreshold(float threshold);

    /** Set the close hysteresis in linear amplitude (0..1). */
    void SetHysteresis(float hysteresis);

    /** Set how quickly the gate opens, in seconds. */
    void SetAttack(float attack);

    /** Set how quickly the gate closes, in seconds. */
    void SetRelease(float release);

    /** Set the closed gain range in linear amplitude (0..1). */
    void SetRange(float range);

    /** Returns the current detector envelope. */
    float GetEnvelope() const { return envelope_; }

    /** Returns the current gain reduction state. */
    float GetGain() const { return gain_; }

    /** Returns true while the gate is open. */
    bool IsOpen() const { return is_open_; }

  private:
    void UpdateAttackCoeff();
    void UpdateReleaseCoeff();

    float sample_rate_;
    float threshold_;
    float hysteresis_;
    float attack_;
    float release_;
    float range_;
    float envelope_;
    float gain_;
    float attack_coeff_;
    float release_coeff_;
    bool  is_open_;
};
} // namespace daisysp
#endif
#endif
