#include "octavegenerator.h"
#include "Utility/dsp.h"
#include <cmath>

using namespace daisysp;

void OctaveGenerator::Init(float sample_rate)
{
    sample_rate_    = sample_rate;
    drive_          = 2.0f;
    tone_           = 0.5f;
    sub_gain_       = 1.0f;
    up_gain_        = 0.0f;
    sub_octave_     = 0.0f;
    octave_up_      = 0.0f;
    last_positive_  = true;
    sub_polarity_   = 1.0f;

    tracker_.Init();
    tracker_.SetFilterMode(OnePole::FILTER_MODE_LOW_PASS);
    tracker_.SetFrequency(600.0f / sample_rate_);

    sub_tone_.Init();
    sub_tone_.SetFilterMode(OnePole::FILTER_MODE_LOW_PASS);

    up_tone_.Init();
    up_tone_.SetFilterMode(OnePole::FILTER_MODE_LOW_PASS);

    sub_dc_.Init(sample_rate_);
    up_dc_.Init(sample_rate_);
    UpdateTone();
}

float OctaveGenerator::Process(float in)
{
    const float driven = tanhf(drive_ * in);
    const float track  = tracker_.Process(driven);
    const bool  positive = track >= 0.0f;
    if(!last_positive_ && positive)
    {
        sub_polarity_ = -sub_polarity_;
    }
    last_positive_ = positive;

    const float amplitude = fabsf(track);
    const float sub_raw   = amplitude * sub_polarity_;
    const float up_raw    = (fabsf(driven) * 2.0f) - 1.0f;

    sub_octave_ = sub_dc_.Process(sub_tone_.Process(sub_raw));
    octave_up_  = up_dc_.Process(up_tone_.Process(up_raw));

    return (sub_gain_ * sub_octave_) + (up_gain_ * octave_up_);
}

void OctaveGenerator::SetDrive(float drive)
{
    drive_ = drive > 0.0f ? drive : 0.0f;
}

void OctaveGenerator::SetTone(float tone)
{
    if(tone < 0.0f)
        tone = 0.0f;
    if(tone > 1.0f)
        tone = 1.0f;
    tone_ = tone;
    UpdateTone();
}

void OctaveGenerator::UpdateTone()
{
    const float sub_cutoff = fclamp(120.0f + (tone_ * 1880.0f), 20.0f, sample_rate_ * 0.45f);
    const float up_cutoff  = fclamp(300.0f + (tone_ * 7700.0f), 20.0f, sample_rate_ * 0.45f);
    sub_tone_.SetFrequency(sub_cutoff / sample_rate_);
    up_tone_.SetFrequency(up_cutoff / sample_rate_);
}
