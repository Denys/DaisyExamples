/** @file octavegenerator.h
 *  @brief Sub-octave and octave-up generator for monophonic pedal inputs.
 *  @ingroup pedal_pitch
 */

/*
Copyright (c) 2026

Use of this source code is governed by an MIT-style
license that can be found in the LICENSE file or at
https://opensource.org/licenses/MIT.
*/

#pragma once
#ifndef DSY_PEDAL_OCTAVEGENERATOR_H
#define DSY_PEDAL_OCTAVEGENERATOR_H

#ifdef __cplusplus
#include "Filters/onepole.h"
#include "Utility/dcblock.h"

namespace daisysp
{
/** Guitar-friendly octave generator that produces sub-octave and octave-up
 *  voices from a monophonic input.
 *
 *  ## Example
 *  ~~~~
 *  OctaveGenerator octave;
 *  octave.Init(48000.0f);
 *  octave.SetSubGain(1.0f);
 *  octave.SetUpGain(0.3f);
 *  float wet = octave.Process(in);
 *  ~~~~
 *
 *  @ingroup pedal_pitch
 */
class OctaveGenerator
{
  public:
    OctaveGenerator() {}
    ~OctaveGenerator() {}

    /** Initialize the octave generator.
     *  \param sample_rate Audio sample rate in Hz.
     */
    void Init(float sample_rate);

    /** Process one sample and return the wet octave mix. */
    float Process(float in);

    /** Input drive before octave extraction. */
    void SetDrive(float drive);

    /** Tone shaping amount in the range 0..1. */
    void SetTone(float tone);

    /** Set the sub-octave blend. */
    void SetSubGain(float gain) { sub_gain_ = gain; }

    /** Set the octave-up blend. */
    void SetUpGain(float gain) { up_gain_ = gain; }

    /** Latest sub-octave voice. */
    float GetSubOctave() const { return sub_octave_; }

    /** Latest octave-up voice. */
    float GetOctaveUp() const { return octave_up_; }

  private:
    void UpdateTone();

    float   sample_rate_;
    float   drive_;
    float   tone_;
    float   sub_gain_;
    float   up_gain_;
    float   sub_octave_;
    float   octave_up_;
    bool    last_positive_;
    float   sub_polarity_;
    OnePole tracker_;
    OnePole sub_tone_;
    OnePole up_tone_;
    DcBlock sub_dc_;
    DcBlock up_dc_;
};
} // namespace daisysp
#endif
#endif
