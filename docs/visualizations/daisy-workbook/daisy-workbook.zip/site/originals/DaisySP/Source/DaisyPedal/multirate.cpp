#include "multirate.h"

using namespace daisysp;

void Multirate::Init(float sample_rate, size_t ratio)
{
    sample_rate_  = sample_rate;
    cutoff_hz_    = sample_rate * 0.25f;
    filtered_     = 0.0f;
    held_         = 0.0f;
    phase_        = 0;
    fresh_sample_ = false;
    anti_alias_.Init();
    anti_alias_.SetFilterMode(OnePole::FILTER_MODE_LOW_PASS);
    SetRatio(ratio);
    SetCutoff(cutoff_hz_);
}

float Multirate::Process(float in)
{
    filtered_     = anti_alias_.Process(in);
    fresh_sample_ = false;

    if(ratio_ <= 1)
    {
        held_         = filtered_;
        fresh_sample_ = true;
        return held_;
    }

    if(++phase_ >= ratio_)
    {
        phase_        = 0;
        held_         = filtered_;
        fresh_sample_ = true;
    }
    return held_;
}

void Multirate::SetRatio(size_t ratio)
{
    ratio_ = ratio > 0 ? ratio : 1;
    phase_ = 0;
}

void Multirate::SetCutoff(float cutoff_hz)
{
    cutoff_hz_ = cutoff_hz > 1.0f ? cutoff_hz : 1.0f;
    anti_alias_.SetFrequency(cutoff_hz_ / sample_rate_);
}
