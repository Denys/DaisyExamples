# DaisyHost Training And Dataset Rendering

Phase 3 adds a headless renderer and a small Python orchestration layer for
offline sweeps.

`DaisyHost Hub.exe` can also dispatch render and dataset jobs through these same
entrypoints. The hub does not replace this workflow; it just prepares or selects
the JSON input and launches the commands below.

## Renderer

Build the CLI:

```sh
cmake -S DaisyHost -B DaisyHost/build
cmake --build DaisyHost/build --config Release --target DaisyHostRender
```

Render one scenario:

```sh
DaisyHost/build/Release/DaisyHostRender.exe DaisyHost/training/examples/multidelay_smoke.json
```

Optional explicit output directory:

```sh
DaisyHost/build/Release/DaisyHostRender.exe DaisyHost/training/examples/torus_smoke.json --output-dir DaisyHost/training/out/torus_smoke
```

Each run writes:

- `audio.wav`
- `manifest.json`

## Agent/CI CLI

`DaisyHostCLI.exe` wraps the same metadata, scenario, render, and smoke
contracts for automation:

```sh
DaisyHost/build/Release/DaisyHostCLI.exe doctor --build-dir DaisyHost/build --source-dir DaisyHost --config Release --json
DaisyHost/build/Release/DaisyHostCLI.exe gate --source-dir DaisyHost --build-dir DaisyHost/build --config Release --json
DaisyHost/build/Release/DaisyHostCLI.exe list-apps --json
DaisyHost/build/Release/DaisyHostCLI.exe describe-app cloudseed --json
DaisyHost/build/Release/DaisyHostCLI.exe describe-board daisy_field --json
DaisyHost/build/Release/DaisyHostCLI.exe validate-scenario DaisyHost/training/examples/multidelay_smoke.json --json
DaisyHost/build/Release/DaisyHostCLI.exe render DaisyHost/training/examples/multidelay_smoke.json --output-dir DaisyHost/build/cli_smoke/tf16_multidelay --expect-non-silent --expect-timeline-target-node node0 --json
DaisyHost/build/Release/DaisyHostCLI.exe smoke --mode render --build-dir DaisyHost/build --source-dir DaisyHost --config Release --json
```

Use `DaisyHostCLI` as a thin offline facade for reproducible agent/CI
inspection and render validation. The existing `snapshot --json` and
`render --json` payloads include additive `debugState` readback for compact
board, selected-node, route, role, and timeline diagnostics. Render payloads
also report `debugState.timeline.events[]`, event `scope`, event
`resolution`, grouped `eventsByTargetNode`, and per-node `eventCount` so
agents can tell which rack node an event affected without manually inferring
it from raw ids. `gate --json` wraps the existing host gate with structured
phase, CTest, and blocker evidence.
`render --json` can also fail directly on expected render evidence with
`--expect-checksum`, `--expect-non-silent`, `--expect-route-count`,
`--expect-node-id`, and `--expect-timeline-target-node`; assertion requests add
an `assertions` report and return validation exit code `2` on mismatch.

The WS13 adoption pilot treats these commands as the standard QA path to repeat
and refine. Recent WS10/TF11 verification proved the normalized `doctor`,
`gate`, direct render/snapshot proof, and direct `cmd /c build_host.cmd` path
green in the active checkout. If a future `gate --json` run reports a
`locked-artifact` while rebuilding `DaisyHostCLI.exe`, use that JSON as failure
evidence and rerun the direct wrapper after the CLI process exits before
claiming a fresh green full gate.

The existing `doctor --json` command is the source/build readiness preflight;
it is not a new command and does not execute the gate. Its stable top-level
fields remain `ok`, `buildDir`, `sourceDir`, `config`, and `checks`. Each check
adds `category`, `kind`, `severity`, and `hint`, while additive top-level
objects report `source`, `build`, `ctest`, `environment`, and `blockers`.
Doctor checks expected source-root files, build-tree files, Hub/VST3 and other
expected artifacts, CTest registrations including `DaisyHostCliDoctor`, and the
duplicate `Path` / `PATH` Windows environment hazard. GUI/live-plugin control,
DAW validation, firmware flashing, generic shell control, and gate execution
remain out of scope for doctor.

Defer new commands until a real workflow proves a missing automation operation.

## Automated Smoke Harness

The host gate now includes a direct-entrypoint smoke harness for the standalone
and render binaries. Run it manually with:

```sh
py -3 DaisyHost/tests/run_smoke.py --mode all --build-dir DaisyHost/build --source-dir DaisyHost --config Release
```

Or run the render-only path with:

```sh
py -3 DaisyHost/tests/run_smoke.py --mode render --build-dir DaisyHost/build --source-dir DaisyHost --config Release
```

The render smoke uses the checked-in app and Field scenario JSON files, writes
fresh harness-owned output directories under `DaisyHost/build/smoke/`, verifies
`audio.wav` plus `manifest.json`, checks repeated `multidelay` render
determinism via `audioChecksum`, and validates Field shell/native/extended
surface plus selected-node surface evidence.

## Scenario Schema

Top-level fields:

- `appId`
- `renderConfig`
- `seed`
- `initialParameterValues`
- `audioInput`
- `timeline`

`renderConfig` fields:

- `sampleRate`
- `blockSize`
- `durationSeconds`
- `outputChannelCount`

`audioInput` fields:

- `mode`: `host_in`, `sine`, `triangle`, `square`, `saw`, `noise`, `impulse`
- `level`: `0..10`
- `frequencyHz`: `20..5000`

Timeline event types:

- `parameter_set`
- `cv_set`
- `gate_set`
- `midi`
- `audio_input_config`
- `impulse`
- `menu_rotate`
- `menu_press`
- `menu_set_item`

## Dataset Job Schema

`render_dataset.py` expands a base scenario into multiple run directories.

Top-level fields:

- `jobName`
- `outputDir`
- either `baseScenario` or `baseScenarioPath`
- `sweeps`

Supported sweep kinds:

- `seed`
- `parameter`
- `audio_input_mode`
- `audio_input_level`
- `audio_input_frequency`

Example:

```json
{
  "jobName": "multidelay_frequency_sweep",
  "baseScenarioPath": "examples/multidelay_smoke.json",
  "outputDir": "out/multidelay_frequency_sweep",
  "sweeps": [
    {
      "kind": "audio_input_frequency",
      "values": [110.0, 220.0, 440.0]
    },
    {
      "kind": "parameter",
      "parameterId": "node0/param/dry_wet",
      "values": [0.25, 0.75]
    }
  ]
}
```

Run the dataset job:

```sh
py -3 DaisyHost/training/render_dataset.py DaisyHost/training/examples/dataset_job_example.json
```
