# Workbook structural QA

{
  "status": "PASS",
  "failures": [],
  "checks": {
    "manifest_file_count": 5695,
    "chapter_count": 24,
    "source_count": 2830,
    "visual_count": 1,
    "search_entry_count": 3355,
    "html_page_count": 2856,
    "broken_internal_links": 0,
    "external_runtime_resources": 0,
    "render_file_count": 23,
    "entries": 502,
    "original_byte_hash_checks": 2829,
    "coverage_unowned_files": 0
  }
}
