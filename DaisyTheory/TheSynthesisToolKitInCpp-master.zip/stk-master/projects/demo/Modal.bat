wish < tcl/Modal.tcl | stk-demo ModalBar -or -ip
